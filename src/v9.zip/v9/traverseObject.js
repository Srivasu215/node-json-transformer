import { resolveValue } from "./value.js";
import traverseArray from "./traverseArray.js";
import extractArrayIndex from "./extractArrayIndex.js";
/*
 * Mapping traversal decides what the current mapping node means.
 * It never searches the source by itself; source lookup belongs to resolve.js.
 */
const traverse = (mapping, source, context) => {
    // console.log("aaaaaa : ", mapping);

    if (
        typeof mapping.list !== "undefined" ||
        typeof mapping.objectify !== "undefined" ||
        typeof mapping.collect !== "undefined"
    ) {
        return traverseArray(mapping, source, context);
    }

    if (typeof mapping.flat !== "undefined") {
        const extracted = extractArrayIndex(mapping.flat, source);
        return startFunc(mapping.item, extracted, context);
    }

    if (typeof mapping.item !== "undefined") {
        return startFunc(mapping.item, source, context);
    }

    return startFunc(mapping, source, context);
};

/*
 * An object mapping defines the output keys. Each instruction tells us how
 * to obtain that output value.
 */
const startFunc = (mapping, source, context) => {
    const result = {};

    Object.keys(mapping).forEach((outputKey) => {
        const instruction = mapping[outputKey];

        if (typeof instruction === "string") {
            result[outputKey] = resolveValue(
                instruction,
                source,
                context.rootSource,
                context.configuration
            );
            return;
        }

        if (Array.isArray(instruction) && instruction.length > 0) {
            result[outputKey] = traverseArray(instruction[0], source, context);
            return;
        }

        if (instruction && typeof instruction === "object") {
            result[outputKey] = traverse(instruction, source, context);
        }
    });

    return result;
};

export default startFunc;