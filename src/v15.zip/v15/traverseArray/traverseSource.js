import traverseObject from "./traverseObject.js";

function isPlainObject(value) {
    return (
        value !== null &&
        typeof value === "object" &&
        Object.getPrototypeOf(value) === Object.prototype
    );
}

/*
 * Traverse a source array using the supplied item mapping.
 */
const traverseArraySource = (
    sourceArray,
    itemMapping,
    context
) => {
    return sourceArray.map((item) => {
        return traverseObject(
            itemMapping,
            item,
            context
        );
    });
};

/*
 * Traverse a source object as a single array element.
 */
const traverseObjectSource = (
    sourceObject,
    itemMapping,
    context
) => {
    return [
        traverseObject(
            itemMapping,
            sourceObject,
            context
        )
    ];
};

/*
 * Normalize source cardinality before traversal.
 *
 * Tally can represent the same LIST as:
 *
 * ""
 * {}
 * []
 *
 * The mapping declares the desired array output.
 */
const startFunc = (
    source,
    itemMapping,
    context
) => {
    if (Array.isArray(source)) {
        return traverseArraySource(
            source,
            itemMapping,
            context
        );
    }

    if (isPlainObject(source)) {
        return traverseObjectSource(
            source,
            itemMapping,
            context
        );
    }

    return [];
};

export default startFunc;